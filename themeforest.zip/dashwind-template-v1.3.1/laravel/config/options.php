<?php return [
    'perpage' => [
        'default' => 10,
        'list' => [10, 20, 50],
    ],
    'order_by' => [
        'default' => 'DESC',
        'list' => ['ASC', 'DESC'],
    ]
];