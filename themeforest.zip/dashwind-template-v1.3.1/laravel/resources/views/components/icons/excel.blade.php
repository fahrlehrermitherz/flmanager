<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 72 72">
<g>
	<g>
		
			<path fill="#FFFFFF" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M49.8,60H22.2c-2.3,0-4.2-2-4.2-4.4V16.4c0-2.4,1.9-4.4,4.2-4.4h20.5L54,23.3v32.3C54,58,52.1,60,49.8,60z"/>
		
			<polyline fill="none" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
			42,12 42,24 54,24.1 		"/>
	</g>
	<g>
		
			<rect x="26" y="32" fill="#F2F9F6" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" width="20" height="20"/>
		
			<line fill="none" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26" y1="37" x2="46" y2="37"/>
		
			<line fill="none" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="33" y1="52" x2="33" y2="32"/>
		
			<line fill="none" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26" y1="42" x2="46" y2="42"/>
		
			<line fill="none" stroke="#3CDC9A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26" y1="47" x2="46" y2="47"/>
	</g>
</g>
</svg>
