<svg width="46" height="46" viewBox="0 0 46 46" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_838_639)">
<path d="M36.972 39.4286H2.94794C1.65823 39.4286 0.614166 38.3845 0.614166 37.0948V2.94793C0.614166 1.65821 1.65823 0.614151 2.94794 0.614151H36.9106C38.2617 0.614151 39.3058 1.65821 39.3058 2.94793V37.0334C39.3058 38.3845 38.2617 39.4286 36.972 39.4286Z" fill="#E3E7FE" stroke="#6576FF" stroke-width="2" stroke-miterlimit="10"/>
<path d="M43.1749 45.5701H9.21229C7.92257 45.5701 6.87851 44.526 6.87851 43.2363V9.08945C6.87851 7.79974 7.92257 6.75568 9.21229 6.75568H43.1749C44.4646 6.75568 45.5087 7.79974 45.5087 9.08945V43.1749C45.5701 44.526 44.526 45.5701 43.1749 45.5701Z" fill="white" stroke="#6576FF" stroke-width="2" stroke-miterlimit="10" stroke-linejoin="round"/>
<path d="M11.8531 29.2336H24.0134" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M21.1883 29.2336H39.8585" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.9146 14.2483H21.9253" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.9146 17.0734H21.9253" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.9146 19.8985H21.9253" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.9146 22.7236H16.6436" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.8531 33.9012H24.0134" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M21.1883 33.9012H39.8585" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M11.8531 38.3845H24.0134" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M21.1883 38.3845H39.8585" stroke="#C4CEFE" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round"/>
<path d="M39.7971 24.6275H26.5928C26.4086 24.6275 26.2857 24.5047 26.2857 24.3204V13.0814C26.2857 12.8972 26.4086 12.7744 26.5928 12.7744H39.7971C39.9813 12.7744 40.1042 12.8972 40.1042 13.0814V24.3204C40.1042 24.5047 39.9813 24.6275 39.7971 24.6275Z" fill="#B3C2FF"/>
<path d="M31.9359 20.0214H30.6462L30.462 20.6355H29.6021L30.8304 17.1963H31.8131L33.0414 20.6355H32.1816L31.9359 20.0214ZM31.7517 19.4072L31.3218 18.1789L30.8919 19.4072H31.7517Z" fill="#6576FF"/>
<path d="M35.6208 17.4419C35.8665 17.5647 36.1122 17.8104 36.235 18.0561C36.3578 18.3017 36.4806 18.6088 36.4806 18.9773C36.4806 19.2844 36.4192 19.5915 36.235 19.8985C36.1122 20.1442 35.8665 20.3898 35.6208 20.5127C35.3752 20.6355 35.0067 20.6969 34.6996 20.6969H33.4099V17.1963H34.6996C35.0681 17.1963 35.3752 17.2577 35.6208 17.4419ZM35.3752 19.6529C35.5594 19.4686 35.6208 19.223 35.6208 18.9159C35.6208 18.6088 35.5594 18.3631 35.3752 18.1789C35.1909 17.9947 34.9453 17.9332 34.6382 17.9332H34.2697V19.8985H34.6382C34.9453 19.8985 35.1909 19.8371 35.3752 19.6529Z" fill="#6576FF"/>
</g>
<defs>
<clipPath id="clip0_838_639">
<rect width="46" height="46" fill="white"/>
</clipPath>
</defs>
</svg>
