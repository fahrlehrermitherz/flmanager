<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 42 45" style="enable-background:new 0 0 42 45;" xml:space="preserve">
<style type="text/css">
	.pig{clip-path:url(#SVGID_2_);fill:#559BFB;}
</style>
<g>
	<g>
		<defs>
			<rect id="SVGID_1_" y="1.5" width="42" height="42"/>
		</defs>
		<clipPath id="SVGID_2_">
			<use xlink:href="#SVGID_1_"  style="overflow:visible;"/>
		</clipPath>
		<path class="pig" d="M26.5,25.7c-0.4-0.5-1-0.6-1.5-0.1l-1,1c-0.5,0.5-1.1,0.4-1.5-0.1l-4.1-5.3c-0.4-0.5-1-0.5-1.2,0.1l-4,8
			c-0.3,0.6,0,1.1,0.6,1.1h14.8c0.7,0,0.9-0.4,0.5-1L26.5,25.7z"/>
		<path class="pig" d="M24.2,20.7c1.3,0,2.4-1.1,2.4-2.4c0-1.3-1.1-2.4-2.4-2.4c-1.3,0-2.4,1.1-2.4,2.4
			C21.8,19.7,22.9,20.7,24.2,20.7"/>
		<path class="pig" d="M21,1.5c-11.6,0-21,9.4-21,21c0,11.6,9.4,21,21,21s21-9.4,21-21C42,10.9,32.6,1.5,21,1.5 M31.8,30.2
			c0,1.3-1.1,2.4-2.4,2.4H12.7c-1.3,0-2.4-1.1-2.4-2.4V14.8c0-1.3,1.1-2.4,2.4-2.4h16.7c1.3,0,2.4,1.1,2.4,2.4V30.2z"/>
	</g>
</g>
</svg>
