<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 42 45" style="enable-background:new 0 0 42 45;" xml:space="preserve">
<style type="text/css">
	.pee{clip-path:url(#SVGID_2_);fill:#FF63A5;}
</style>
<g>
	<defs>
		<rect id="SVGID_1_" y="1.5" width="42" height="42"/>
	</defs>
	<clipPath id="SVGID_2_">
		<use xlink:href="#SVGID_1_"  style="overflow:visible;"/>
	</clipPath>
	<path class="pee" d="M27.5,36c-0.6,0-1.3-0.2-1.7-0.7c-1-1-1-2.5,0-3.5l15.4-15.4c-0.6-2.1-1.6-4.1-2.8-5.8L25.2,23.8
		c-0.5,0.5-1.1,0.7-1.7,0.7c-0.6,0-1.3-0.2-1.7-0.7c-1-1-1-2.5,0-3.5L35.1,6.9c-2-1.8-4.4-3.3-7.1-4.2L11.7,19
		c-0.5,0.5-1.1,0.7-1.7,0.7c-0.6,0-1.3-0.2-1.7-0.7c-1-1-1-2.5,0-3.5l14-14c-0.4,0-0.8,0-1.3,0c-11.6,0-21,9.4-21,21
		c0,11.6,9.4,21,21,21s21-9.4,21-21c0,0,0,0,0,0L29.2,35.3C28.7,35.8,28.1,36,27.5,36 M21.9,31.2c-0.5,0.5-1.1,0.7-1.7,0.7
		c-0.6,0-1.3-0.2-1.7-0.7L13.2,26c-1-1-1-2.5,0-3.5c1-1,2.5-1,3.5,0l5.3,5.3C22.9,28.7,22.9,30.3,21.9,31.2"/>
</g>
</svg>
