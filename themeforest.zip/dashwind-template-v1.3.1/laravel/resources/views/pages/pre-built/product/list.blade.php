@extends('layouts.main', ['title'=> 'Product List'])
@section('content')
<div class="flex justify-between items-center pb-5 md:pb-7 relative">
    <div>
        <h3 class="font-heading font-bold text-2xl lg:text-3xl leading-tighter tracking-tight text-slate-700 dark:text-white">Products</h3>
    </div>
    <div>
        <button data-target="#pageOptions" class="class-toggle sm:hidden *:pointer-events-none -me-2 inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900">
            <em class="text-xl text-slate-600 dark:text-slate-300 ni ni-more-v"></em>
        </button>
        <div id="pageOptions" class="absolute sm:relative start-0 end-0 top-full sm:mt-1 -mx-3.5 bg-white dark:bg-gray-950 sm:bg-transparent sm:dark:bg-transparent max-sm:shadow max-sm:dark:shadow-gray-800  opacity-0 invisible sm:opacity-100 sm:visible [&.active]:opacity-100 [&.active]:visible z-[700]">
            <ul class="flex items-center gap-4 px-3.5 py-5 sm:py-0">
                <li>
                    <div class="relative max-w-[190px]">
                        <div class="absolute h-9 w-9 top-0 end-0 flex items-center justify-center">
                            <em class="text-slate-400 text-base leading-none ni ni-search"></em>
                        </div>
                        <input type="text" class="block w-full text-sm leading-4.5 pe-10 ps-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="default-03" placeholder="Quick search by id" autocomplete="off">
                    </div>
                </li>
                <li>
                    <div class="dropdown relative">
                        <a href="#" data-offset="0,4" data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer relative inline-flex items-center text-center align-middle text-sm font-heading font-bold leading-4.5 rounded px-4.5 py-2 tracking-wide border border-gray-300 dark:border-gray-900 text-slate-600 dark:text-slate-200 bg-white dark:bg-gray-900 hover:bg-slate-600 [&.show]:bg-slate-600 hover:dark:bg-gray-800 [&.show]:dark:bg-gray-800 hover:text-white [&.show]:text-white hover:dark:text-white [&.show]:dark:text-white hover:border-slate-600 hover:dark:border-gray-800 [&.show]:dark:border-gray-800 active:bg-slate-700 active:text-white active:border-slate-600 transition-all duration-300">
                            <span class="me-1">Status</span>
                            <em class="-me-1 text-base leading-4.5 ni ni-chevron-down"></em>
                        </a>
                        <div class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded-md shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li><a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#"><span>New Items</span></a></li>
                                <li><a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#"><span>Featured</span></a></li>
                                <li><a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#"><span>Out of Stock</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="ms-auto">
                    <button data-target="#pageAside" data-body-scroll="off" class="class-toggle *:pointer-events-none relative inline-flex sm:hidden items-center justify-center text-center align-middle text-sm font-bold leading-4.5 rounded h-9 w-9 tracking-wide border border-primary-600 text-white bg-primary-600 hover:bg-primary-700 active:bg-primary-800 transition-all duration-300">
                        <em class="text-xl leading-4.5 ni ni-plus"></em>
                    </button>
                    <button data-target="#pageAside" data-body-scroll="off" class="class-toggle *:pointer-events-none relative hidden sm:inline-flex items-center text-center align-middle text-sm font-bold leading-4.5 rounded px-5 py-2 tracking-wide border border-primary-600 text-white bg-primary-600 hover:bg-primary-700 active:bg-primary-800 transition-all duration-300">
                        <em class="text-xl leading-4.5 ni ni-plus"></em>
                        <span class="ms-3">Add Product</span>
                    </button>
                </li>
            </ul>
        </div>
    </div>
</div><!-- block head -->
<div class="border-y sm:border-x sm:rounded-md bg-white dark:bg-gray-950 border-gray-300 dark:border-gray-900 h-full -mx-3.5 sm:m-0">
    <table class="border-collapse w-full border-gray-300 dark:border-gray-900"> 
        <thead>
            <tr>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-all">
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start hidden sm:table-cell">
                    <span class="block text-xs/5 text-slate-400 font-normal">Name</span>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start">
                    <span class="block text-xs/5 text-slate-400 font-normal">SKU</span>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start">
                    <span class="block text-xs/5 text-slate-400 font-normal">Price</span>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start">
                    <span class="block text-xs/5 text-slate-400 font-normal">Stock</span>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start hidden md:table-cell">
                    <span class="block text-xs/5 text-slate-400 font-normal">Category</span>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-start hidden md:table-cell">
                    <em class="block text-lg/5 text-slate-400 ni ni-star-round"></em>
                </th>
                <th class="py-2 px-2 first:ps-6 last:pe-6 border-b align-middle border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2 -my-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Selected</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Selected</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-bar-c"></em>
                                        <span>Update Stock</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-invest"></em>
                                        <span>Update Price</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </th>
            </tr>
        </thead>
        <tbody>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-1">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/a.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Pink Fitness Tracker
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3749</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 99.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Fitbit, Tracker</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-2">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/b.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Purple Smartwatch
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3750</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 89.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">103</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Gadgets, Fitbit, Tracker</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-3">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/c.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Black Mi Band Smartwatch
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3751</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 299.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">68</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Smartwatch, Tracker</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer active">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-4">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/d.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Black Headphones
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3752</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 99.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">77</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Headphone, Gadgets</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-5">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/e.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            iPhone 7 Headphones
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3753</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 129.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">81</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Headphone, Gadgets</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-6">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/f.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Purple Blue Gradient iPhone Case
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3754</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 29.00</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">28</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Case, Gadgets</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-7">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/g.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Plug In Speaker
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3755</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 19.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">62</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Gadgets, Speaker</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-8">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/h.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Wireless Waterproof Speaker
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3756</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 59.00</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">37</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Speaker, Gadgets</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-9">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/j.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            AliExpress Fitness Trackers
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3758</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 35.99</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">145</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Fitbit, Tracker</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
            <tr class="transition-all duration-300 hover:bg-gray-50 hover:dark:bg-gray-1000 group">
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 w-12 sm:w-13">
                    <input type="checkbox" class="peer h-4 w-4 bg-white dark:bg-gray-950 checked:bg-primary-600 checked:dark:bg-primary-600 checked:hover:bg-primary-600 checked:hover:dark:bg-primary-600 checked:focus:bg-primary-600 checked:focus:dark:bg-primary-600 focus:border-primary-600 focus:dark:border-primary-600 outline-none focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 focus:ring-0 focus:ring-offset-0 disabled:bg-slate-50 disabled:dark:bg-slate-900 disabled:checked:bg-primary-400 disabled:checked:dark:bg-primary-400 rounded border-2 border-gray-300 dark:border-gray-900 checked:dark:border-primary-600  cursor-pointer disabled:cursor-not-allowed transition-all duration-300" id="uid-10">
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden sm:table-cell">
                    <div class="flex items-center">
                        <div class="relative flex-shrink-0 flex items-center justify-center text-xxs text-white bg-primary-600 h-12 w-12 rounded font-medium">
                            <img class="rounded" src="{{ asset('images/product/i.png') }}" alt="">
                        </div>
                        <span class="ms-4 block text-sm font-medium leading-6 text-slate-700 dark:text-white">
                            Pool Party Drink Holder
                        </span>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">UY3757</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-sm font-medium text-slate-700 dark:text-white">$ 9.49</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900">
                    <span class="text-xs text-slate-400">73</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <span class="text-xs text-slate-400">Men, Holder</span>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 hidden md:table-cell">
                    <div class="inline-flex relative group/asterisk cursor-pointer">
                        <em class="text-lg/none text-primary-600 ni ni-star"></em>
                        <em class="text-lg/none text-yellow-600 absolute top-0 opacity-0 group-hover/asterisk:opacity-100 group-[.active]/asterisk:opacity-100 ni ni-star-fill"></em>
                    </div>
                </td>
                <td class="py-4 px-2 first:ps-6 last:pe-6 border-b border-gray-300 dark:border-gray-900 text-end max-w-[3.75rem]">
                    <div class="dropdown relative -me-2">
                        <button data-offset="-14, -8" data-rtl-offset="14, -8"  data-placement="bottom-end"  data-rtl-placement="bottom-start" class="dropdown-toggle *:pointer-events-none peer inline-flex items-center justify-center isolate relative h-9 w-9 px-1.5 before:content-[''] before:absolute before:-z-[1] before:h-5 before:w-5 hover:before:h-10 hover:before:w-10 [&.show]:before:h-10 [&.show]:before:w-10 before:rounded-full before:opacity-0 hover:before:opacity-100 [&.show]:before:opacity-100 before:transition-all before:duration-300 before:-translate-x-1/2  before:-translate-y-1/2 before:top-1/2 before:left-1/2 before:bg-gray-200 dark:before:bg-gray-900 text-slate-500 dark:text-slate-300">
                            <em class="text-xl ni ni-more-h"></em>
                        </button>
                        <div tabindex="0" class="dropdown-menu absolute min-w-[180px] border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 rounded shadow hidden peer-[.show]:block z-[1000]">
                            <ul class="py-2">
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-edit"></em>
                                        <span>Edit Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-eye"></em>
                                        <span>View Product</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-activity-round"></em>
                                        <span>Product Orders</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="relative px-5 py-2.5 flex items-center rounded-[inherit] text-xs leading-5 font-medium text-slate-600 dark:text-slate-300 hover:text-primary-600 hover:bg-slate-50 hover:dark:bg-gray-900 transition-all duration-300" href="#">
                                        <em class="text-start text-lg leading-none w-7 opacity-80 ni ni-trash"></em>
                                        <span>Remove Product</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- dropdown -->
                </td>
            </tr>
        </tbody>
    </table>
    <div class="p-5">
        <div class="flex flex-wrap justify-center sm:justify-between gap-4">
            <div class="inline-flex align-middle -space-x-px">
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e px-4 py-2 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">Prev</a>
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e w-9 h-9 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">1</a>
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e w-9 h-9 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">2</a>
                <div class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e w-9 h-9 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:z-10 transition-all duration-300"><em class="icon ni ni-more-h"></em></div>
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e w-9 h-9 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">6</a>
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e w-9 h-9 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">7</a>
                <a href="#" class="relative inline-flex items-center justify-center text-center align-middle text-sm font-normal leading-4.5 first:rounded-s last:rounded-e px-4 py-2 tracking-wide border border-gray-200 dark:border-gray-800 text-slate-500 hover:bg-slate-100 hover:dark:bg-slate-800 hover:text-primary-600 active:bg-primary-700 hover:z-10 transition-all duration-300">Next</a>
            </div>
            <div class="flex items-center gap-x-4">
                <div class="text-xs uppercase text-slate-600">Page</div>
                <div class="relative w-16">
                    <select class="js-select block w-full text-sm leading-4.5 pe-10 ps-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950 disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" data-search="true">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                </div>
                <div class="text-xs uppercase text-slate-600">Of 102</div>
            </div>
        </div>
    </div>
</div>
<div id="pageAside" class="peer max-w-[calc(100%-2.5rem)] w-[400px] min-h-screen bg-white dark:bg-gray-950 border-s border-gray-300 dark:border-gray-900 flex-shrink-0 fixed top-0 end-0 z-[999] transition-transform duration-500 translate-x-full rtl:-translate-x-full [&.active]:transform-none">
    <div class="mt-16 max-h-[calc(100vh-theme(spacing.16))]" data-simplebar>
        <div class="p-5 sm:p-6">
            <div class="relative mb-5">
                <h5 class="text-xl/6 text-slate-700 dark:text-white font-heading font-bold -tracking-snug mb-2">New Product</h5>
                <p>Add information and add new product.</p>
            </div>
            <div class="grid grid-flow-dense grid-cols-12 gap-7">
                <div class="col-span-12">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="product-title">Product Title</label>
                        <div class="relative">
                            <input type="text" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="product-title">
                        </div>
                    </div>
                </div>
                <div class="col-span-12 xs:col-span-6">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="regular-price">Regular Price</label>
                        <div class="relative">
                            <input type="number" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="regular-price" autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="col-span-12 xs:col-span-6">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="sale-price">Sale Price</label>
                        <div class="relative">
                            <input type="number" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="sale-price">
                        </div>
                    </div>
                </div>
                <div class="col-span-12 xs:col-span-6">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="stock">Stock</label>
                        <div class="relative">
                            <input type="text" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="stock">
                        </div>
                    </div>
                </div>
                <div class="col-span-12 xs:col-span-6">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="SKU">SKU</label>
                        <div class="relative">
                            <input type="text" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="SKU">
                        </div>
                    </div>
                </div>
                <div class="col-span-12">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="category">Category</label>
                        <div class="relative">
                            <input type="text" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="category">
                        </div>
                    </div>
                </div>
                <div class="col-span-12">
                    <div class="relative mb-5 last:mb-0">
                        <label class="inline-block text-sm font-medium text-slate-700 dark:text-white mb-2" for="tags">Tags</label>
                        <div class="relative">
                            <input type="text" class="block w-full box-border text-sm leading-4.5 px-4 py-1.5 h-9 text-slate-700 dark:text-white placeholder-slate-300 bg-white dark:bg-gray-950 border border-gray-200 dark:border-gray-800 outline-none focus:border-primary-500 focus:dark:border-primary-600 focus:outline-offset-0 focus:outline-primary-200 focus:dark:outline-primary-950  disabled:bg-slate-50 disabled:dark:bg-slate-950 disabled:cursor-not-allowed rounded transition-all" id="tags">
                        </div>
                    </div>
                </div>
                <div class="col-span-12">
                    <div class="js-upload !bg-gray-50 dark:!bg-gray-950" id="DropzoneDefault">
                        <div class="dz-message !my-4" data-dz-message>
                            <span class="block text-sm text-slate-400">Drag and drop file</span>
                        </div>
                    </div>
                </div>
                <div class="col-span-12">
                    <button class="relative inline-flex items-center text-center align-middle text-sm font-bold leading-4.5 rounded px-5 py-2 tracking-wide border border-primary-600 text-white bg-primary-600 hover:bg-primary-700 active:bg-primary-800 transition-all duration-300"><em class="text-xl leading-4.5 ni ni-plus"></em><span class="ms-3">Add New</span></button>
                </div>
            </div>
        </div>
    </div>
</div>
<div data-target="#pageAside" data-body-scroll="off" class="class-toggle fixed inset-0 bg-slate-950 bg-opacity-20 z-[900] opacity-0 invisible peer-[.active]:opacity-100 peer-[.active]:visible"></div>
@endsection