@extends('layouts.main', ['title'=> 'Blank Page'])
@section('content')
<p>Starter page for general layout.</p>
@endsection